export type ChatGPTModel = 'gpt-4o' | 'gpt-4o-mini' | 'o1' | 'o3-mini' | 'canvas';

export interface CanvasDocument {
  id: string;
  title: string;
  type: 'code' | 'text' | 'html' | 'markdown' | 'react';
  language?: string;
  content: string;
  version?: number;
}

export interface Attachment {
  id: string;
  name: string;
  size: string;
  type: 'image' | 'file' | 'code';
  content?: string;
  mimeType?: string;
}

export interface SearchSource {
  title: string;
  url: string;
  snippet?: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  modelUsed?: ChatGPTModel;
  reasoning?: string;
  reasoningTimeSeconds?: number;
  canvas?: CanvasDocument;
  imageUrl?: string;
  sources?: SearchSource[];
  attachments?: Attachment[];
  audioBase64?: string;
  isAudioLoading?: boolean;
  feedback?: 'like' | 'dislike';
}

export interface CustomGPT {
  id: string;
  name: string;
  description: string;
  icon: string;
  instructions: string;
  author: string;
  category: 'Geral' | 'Produtividade' | 'Programação' | 'Escrita' | 'Educação' | 'Estilo de Vida';
  capabilities: {
    webSearch: boolean;
    imageGen: boolean;
    codeInterpreter: boolean;
  };
  starterPrompts: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  updatedAt: string;
  messages: Message[];
  gptId?: string;
  model: ChatGPTModel;
  isTemporary?: boolean;
  isPinned?: boolean;
}

export interface UserSettings {
  aboutUser: string;
  responseStyle: string;
  theme: 'dark' | 'light' | 'system';
  voice: 'alloy' | 'echo' | 'fable' | 'onyx' | 'nova' | 'shimmer';
  enableWebSearch: boolean;
  enableReasoning: boolean;
}

