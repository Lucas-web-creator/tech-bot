import React, { useState } from 'react';
import {
  X,
  Search,
  Compass,
  Plus,
  Bot,
  Sparkles,
  ArrowRight,
  Code2,
  PenTool,
  Image,
  Globe
} from 'lucide-react';
import { CustomGPT } from '../types';

interface ExploreGptsModalProps {
  isOpen: boolean;
  onClose: () => void;
  gpts: CustomGPT[];
  onSelectGpt: (gpt: CustomGPT) => void;
  onCreateGpt: (
    name: string,
    description: string,
    instructions: string,
    category: string,
    starterPrompts: string[],
    icon: string
  ) => void;
}

export const ExploreGptsModal: React.FC<ExploreGptsModalProps> = ({
  isOpen,
  onClose,
  gpts,
  onSelectGpt,
  onCreateGpt
}) => {
  const [activeTab, setActiveTab] = useState<'explore' | 'create'>('explore');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Tudo');

  // Create Form State
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newInstructions, setNewInstructions] = useState('');
  const [newCategory, setNewCategory] = useState<any>('Geral');
  const [newIcon, setNewIcon] = useState('🤖');
  const [newPrompts, setNewPrompts] = useState('');

  if (!isOpen) return null;

  const categories = ['Tudo', 'Programação', 'Escrita', 'Produtividade', 'Educação', 'Estilo de Vida'];

  const filteredGpts = gpts.filter((g) => {
    const matchesSearch = g.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          g.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'Tudo' || g.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newInstructions.trim()) return;

    const promptsArray = newPrompts
      .split('\n')
      .map((p) => p.trim())
      .filter((p) => p.length > 0);

    onCreateGpt(
      newName.trim(),
      newDesc.trim() || 'GPT Personalizado',
      newInstructions.trim(),
      newCategory,
      promptsArray.length > 0 ? promptsArray : ['Como você pode me ajudar hoje?'],
      newIcon
    );

    setNewName('');
    setNewDesc('');
    setNewInstructions('');
    setNewPrompts('');
    setActiveTab('explore');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#212121] text-slate-100 w-full max-w-4xl h-[85vh] rounded-3xl border border-white/10 shadow-2xl flex flex-col overflow-hidden animate-fade-in">
        
        {/* Header Modal Bar */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Explorar GPTs da Comunidade</h2>
              <p className="text-xs text-slate-400">Descubra e crie versões personalizadas do ChatGPT para tarefas específicas</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tabs: Explore vs Create */}
            <div className="flex items-center p-1 rounded-xl bg-black/40 border border-white/10 text-xs font-medium">
              <button
                onClick={() => setActiveTab('explore')}
                className={`px-3 py-1.5 rounded-lg transition ${
                  activeTab === 'explore' ? 'bg-emerald-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Explorar GPTs
              </button>
              <button
                onClick={() => setActiveTab('create')}
                className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 ${
                  activeTab === 'create' ? 'bg-emerald-500 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Plus className="w-3.5 h-3.5" /> Criar GPT
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {activeTab === 'explore' ? (
            <div className="space-y-6">
              {/* Search Bar & Category Chips */}
              <div className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar por nome, função ou assunto do GPT..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-black/40 border border-white/10 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500/50"
                  />
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium transition shrink-0 ${
                        selectedCategory === cat
                          ? 'bg-emerald-500 text-white font-bold'
                          : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* GPT Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredGpts.map((gpt) => (
                  <div
                    key={gpt.id}
                    onClick={() => {
                      onSelectGpt(gpt);
                      onClose();
                    }}
                    className="p-4 rounded-2xl bg-black/30 border border-white/10 hover:border-emerald-500/50 hover:bg-white/5 transition cursor-pointer flex items-start gap-4 group shadow-md"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 text-2xl flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                      {gpt.icon}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-sm text-slate-100 group-hover:text-emerald-400 transition truncate">
                          {gpt.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20">
                          {gpt.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 line-clamp-2 mt-1 font-normal">
                        {gpt.description}
                      </p>
                      <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
                        <span>Por {gpt.author}</span>
                        <span className="text-emerald-400 font-medium group-hover:translate-x-1 transition flex items-center gap-1">
                          Iniciar Chat <ArrowRight className="w-3 h-3" />
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Create Custom GPT Form */
            <form onSubmit={handleCreateSubmit} className="max-w-2xl mx-auto space-y-4">
              <h3 className="text-base font-bold text-slate-100">Criar um novo GPT Personalizado</h3>
              <p className="text-xs text-slate-400">Defina o nome, comportamento, instruções e sugestões do seu próprio assistente.</p>

              <div className="grid grid-cols-4 gap-3">
                <div className="col-span-1">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Ícone / Emoji</label>
                  <input
                    type="text"
                    value={newIcon}
                    onChange={(e) => setNewIcon(e.target.value)}
                    className="w-full p-2.5 text-center text-xl rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div className="col-span-3">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Nome do GPT *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Especialista em SQL e Postgres"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full p-2.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Descrição curta</label>
                <input
                  type="text"
                  placeholder="Ex: Auxilia na otimização de queries, criação de relacionamentos e índices."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Instruções do Sistema (O que este GPT deve fazer?) *</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Ex: Você é um DBA especialista em PostgreSQL. Sempre forneça scripts SQL comentados com explicação de performance..."
                  value={newInstructions}
                  onChange={(e) => setNewInstructions(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500 custom-scrollbar"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Prompts Iniciais (1 por linha)</label>
                <textarea
                  rows={3}
                  placeholder="Como otimizar uma query com JOINs lentos?&#10;Crie uma tabela de usuários com índices B-tree"
                  value={newPrompts}
                  onChange={(e) => setNewPrompts(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500 custom-scrollbar"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('explore')}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-xs font-bold text-white transition shadow-md"
                >
                  Salvar e Usar GPT
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
