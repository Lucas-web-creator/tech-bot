import React, { useState } from 'react';
import {
  X,
  Code2,
  FileText,
  Copy,
  Check,
  Download,
  Play,
  Eye,
  Edit3,
  Send,
  Sparkles,
  Layout,
  RefreshCw
} from 'lucide-react';
import { CanvasDocument } from '../types';

interface CanvasViewerProps {
  canvas: CanvasDocument;
  onClose: () => void;
  onUpdateCanvasContent?: (newContent: string) => void;
  onSendCanvasPrompt?: (promptText: string) => void;
}

export const CanvasViewer: React.FC<CanvasViewerProps> = ({
  canvas,
  onClose,
  onUpdateCanvasContent,
  onSendCanvasPrompt
}) => {
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>(
    canvas.type === 'html' || canvas.type === 'react' ? 'preview' : 'editor'
  );
  const [editedContent, setEditedContent] = useState(canvas.content);
  const [copied, setCopied] = useState(false);
  const [canvasPrompt, setCanvasPrompt] = useState('');

  const handleCopy = () => {
    navigator.clipboard.writeText(editedContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const ext = canvas.language === 'python' ? 'py' : canvas.language === 'javascript' ? 'js' : canvas.type === 'html' ? 'html' : 'txt';
    const blob = new Blob([editedContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${canvas.title.toLowerCase().replace(/\s+/g, '-')}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSendPrompt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canvasPrompt.trim()) return;
    if (onSendCanvasPrompt) {
      onSendCanvasPrompt(`[Ajuste no Canvas "${canvas.title}"]: ${canvasPrompt.trim()}`);
      setCanvasPrompt('');
    }
  };

  // Generate HTML srcDoc for Live Preview
  const getPreviewHtml = () => {
    if (canvas.type === 'html' || editedContent.includes('<html') || editedContent.includes('<div')) {
      return `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <script src="https://cdn.tailwindcss.com"></script>
            <style>body { font-family: system-ui, sans-serif; padding: 1rem; }</style>
          </head>
          <body>
            ${editedContent}
          </body>
        </html>
      `;
    }
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body className="p-4 bg-slate-900 text-white font-mono text-sm whitespace-pre-wrap">
          ${editedContent.replace(/</g, '&lt;').replace(/>/g, '&gt;')}
        </body>
      </html>
    `;
  };

  return (
    <div className="w-full md:w-[500px] lg:w-[650px] xl:w-[750px] h-full bg-[#181818] border-l border-white/10 flex flex-col z-30 shadow-2xl transition-all">
      {/* Canvas Top Header */}
      <div className="p-3 bg-[#212121] border-b border-white/10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
            <Layout className="w-4 h-4" />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-slate-100 truncate">{canvas.title}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-slate-300 font-mono">
                Canvas v{canvas.version || 1}
              </span>
            </div>
            <span className="text-xs text-slate-400 capitalize">{canvas.language || canvas.type}</span>
          </div>
        </div>

        {/* Action Controls & Close */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Tabs: Editor vs Preview */}
          <div className="flex items-center p-0.5 rounded-xl bg-black/40 border border-white/10 text-xs">
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                activeTab === 'editor' ? 'bg-white/20 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" /> Código / Texto
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`px-2.5 py-1 rounded-lg font-medium transition flex items-center gap-1 ${
                activeTab === 'preview' ? 'bg-emerald-500 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" /> Visualizar
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition"
            title="Copiar conteúdo"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>

          <button
            onClick={handleDownload}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition"
            title="Baixar arquivo"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition"
            title="Fechar Canvas"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Canvas Body Area */}
      <div className="flex-1 overflow-hidden relative">
        {activeTab === 'editor' ? (
          <textarea
            value={editedContent}
            onChange={(e) => {
              setEditedContent(e.target.value);
              if (onUpdateCanvasContent) onUpdateCanvasContent(e.target.value);
            }}
            className="w-full h-full p-4 bg-[#141414] text-slate-200 font-mono text-sm leading-relaxed resize-none focus:outline-none custom-scrollbar"
            spellCheck={false}
          />
        ) : (
          <iframe
            srcDoc={getPreviewHtml()}
            title="Live Canvas Preview"
            className="w-full h-full bg-white border-none"
            sandbox="allow-scripts"
          />
        )}
      </div>

      {/* Bottom Canvas Prompt Box for In-Context Adjustments */}
      <div className="p-3 bg-[#212121] border-t border-white/10">
        <form onSubmit={handleSendPrompt} className="flex items-center gap-2 bg-black/40 border border-white/10 rounded-2xl p-1.5 focus-within:border-emerald-500/50">
          <div className="pl-2 text-emerald-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <input
            type="text"
            placeholder="Pedir ao ChatGPT para editar ou aprimorar no Canvas..."
            value={canvasPrompt}
            onChange={(e) => setCanvasPrompt(e.target.value)}
            className="flex-1 bg-transparent border-none text-xs md:text-sm text-slate-100 placeholder-slate-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!canvasPrompt.trim()}
            className={`p-2 rounded-xl transition ${
              canvasPrompt.trim()
                ? 'bg-emerald-500 text-white hover:bg-emerald-600'
                : 'bg-white/5 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
