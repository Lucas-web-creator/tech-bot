import React, { useState } from 'react';
import {
  ChevronDown,
  Sparkles,
  Globe,
  Brain,
  Layout,
  Share2,
  Lock,
  Zap,
  Bot,
  SlidersHorizontal,
  Moon,
  Sun
} from 'lucide-react';
import { ChatGPTModel, CustomGPT } from '../types';

interface HeaderProps {
  selectedModel: ChatGPTModel;
  onSelectModel: (model: ChatGPTModel) => void;
  enableWebSearch: boolean;
  onToggleWebSearch: () => void;
  enableReasoning: boolean;
  onToggleReasoning: () => void;
  isCanvasOpen: boolean;
  onToggleCanvas: () => void;
  isTemporaryChat: boolean;
  onToggleTemporaryChat: () => void;
  activeGpt?: CustomGPT;
  onOpenGptStore: () => void;
  onOpenSettings: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onShareChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedModel,
  onSelectModel,
  enableWebSearch,
  onToggleWebSearch,
  enableReasoning,
  onToggleReasoning,
  isCanvasOpen,
  onToggleCanvas,
  isTemporaryChat,
  onToggleTemporaryChat,
  activeGpt,
  onOpenGptStore,
  onOpenSettings,
  darkMode,
  onToggleDarkMode,
  onShareChat
}) => {
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);

  const modelLabels: Record<ChatGPTModel, { title: string; subtitle: string; icon: any; tag?: string }> = {
    'gpt-4o': {
      title: 'ChatGPT 4o',
      subtitle: 'Nosso modelo mais inteligente e versátil para tarefas do dia a dia e multimídia',
      icon: Sparkles,
      tag: 'Mais Popular'
    },
    'gpt-4o-mini': {
      title: 'ChatGPT 4o mini',
      subtitle: 'Rápido e leve para tarefas cotidianas e respostas ágeis',
      icon: Zap
    },
    'o1': {
      title: 'o1 (Raciocínio)',
      subtitle: 'Pensamento profundo para matemática, código complexo e ciências',
      icon: Brain,
      tag: 'Avançado'
    },
    'o3-mini': {
      title: 'o3-mini',
      subtitle: 'Modelo de raciocínio lógico otimizado para velocidade',
      icon: Brain
    },
    'canvas': {
      title: 'Canvas',
      subtitle: 'Colabore lado a lado em textos e projetos de código',
      icon: Layout
    }
  };

  const currentModel = modelLabels[selectedModel];

  return (
    <header className="sticky top-0 z-20 flex items-center justify-between px-4 py-2.5 bg-[#212121]/90 dark:bg-[#171717]/90 bg-white/90 backdrop-blur-md border-b border-black/5 dark:border-white/10 text-slate-800 dark:text-slate-100 transition-colors">
      {/* Left: Model Selector Dropdown or Active Custom GPT */}
      <div className="relative">
        {activeGpt ? (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition cursor-pointer" onClick={onOpenGptStore}>
            <span className="text-xl">{activeGpt.icon}</span>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-sm">{activeGpt.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium">GPT</span>
              </div>
              <span className="text-xs text-slate-500 dark:text-slate-400 truncate max-w-[200px]">{activeGpt.description}</span>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setIsModelDropdownOpen(!isModelDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 text-base font-semibold tracking-tight transition"
          >
            <span className="text-emerald-500 dark:text-emerald-400">
              <currentModel.icon className="w-5 h-5" />
            </span>
            <span>{currentModel.title}</span>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isModelDropdownOpen ? 'rotate-180' : ''}`} />
          </button>
        )}

        {/* Dropdown Menu */}
        {isModelDropdownOpen && (
          <>
            <div className="fixed inset-0 z-30" onClick={() => setIsModelDropdownOpen(false)} />
            <div className="absolute top-full left-0 mt-2 w-80 rounded-2xl bg-white dark:bg-[#212121] border border-black/10 dark:border-white/10 shadow-2xl p-2 z-40 space-y-1">
              {(Object.keys(modelLabels) as ChatGPTModel[]).map((modelKey) => {
                const item = modelLabels[modelKey];
                const IconComponent = item.icon;
                const isSelected = selectedModel === modelKey;

                return (
                  <button
                    key={modelKey}
                    onClick={() => {
                      onSelectModel(modelKey);
                      setIsModelDropdownOpen(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-start gap-3 transition ${
                      isSelected
                        ? 'bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                        : 'hover:bg-slate-100 dark:hover:bg-white/5 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="mt-0.5 p-1.5 rounded-lg bg-black/5 dark:bg-white/5">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm">{item.title}</span>
                        {item.tag && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-semibold">
                            {item.tag}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5 font-normal">
                        {item.subtitle}
                      </p>
                    </div>
                  </button>
                );
              })}

              <div className="pt-1 mt-1 border-t border-black/5 dark:border-white/10">
                <button
                  onClick={() => {
                    setIsModelDropdownOpen(false);
                    onOpenGptStore();
                  }}
                  className="w-full text-left p-2 rounded-xl flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 transition"
                >
                  <Bot className="w-4 h-4 text-emerald-500" />
                  <span>Explorar GPTs da Comunidade...</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Right: Quick Action Toggles & Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Web Search Toggle */}
        <button
          onClick={onToggleWebSearch}
          title={enableWebSearch ? 'Pesquisa Web ativada' : 'Ativar Pesquisa Web'}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
            enableWebSearch
              ? 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30'
              : 'text-slate-500 hover:bg-black/5 dark:hover:bg-white/5'
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Pesquisar Web</span>
        </button>

        {/* Reasoning Toggle */}
        <button
          onClick={onToggleReasoning}
          title={enableReasoning ? 'Raciocínio ativado' : 'Ativar Raciocínio'}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
            enableReasoning
              ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30'
              : 'text-slate-500 hover:bg-black/5 dark:hover:bg-white/5'
          }`}
        >
          <Brain className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Raciocínio</span>
        </button>

        {/* Canvas Side Panel Toggle */}
        <button
          onClick={onToggleCanvas}
          title="Alternar modo Canvas"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition ${
            isCanvasOpen
              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
              : 'text-slate-500 hover:bg-black/5 dark:hover:bg-white/5'
          }`}
        >
          <Layout className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Canvas</span>
        </button>

        {/* Temporary Chat Toggle */}
        <button
          onClick={onToggleTemporaryChat}
          title={isTemporaryChat ? 'Conversa temporária (Sem histórico)' : 'Modo normal'}
          className={`p-2 rounded-xl transition ${
            isTemporaryChat
              ? 'bg-purple-500/20 text-purple-400 ring-1 ring-purple-500/40'
              : 'text-slate-400 hover:bg-black/5 dark:hover:bg-white/5'
          }`}
        >
          <Lock className="w-4 h-4" />
        </button>

        {/* Dark/Light mode toggle */}
        <button
          onClick={onToggleDarkMode}
          className="p-2 rounded-xl text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 transition"
          title={darkMode ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
        >
          {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Share Chat */}
        <button
          onClick={onShareChat}
          className="p-2 rounded-xl text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 transition"
          title="Exportar / Compartilhar conversa"
        >
          <Share2 className="w-4 h-4" />
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-xl text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 transition"
          title="Configurações e Personalização"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
