import React, { useState } from 'react';
import {
  SquarePen,
  Compass,
  Search,
  MessageSquare,
  Pin,
  Trash2,
  Edit2,
  Check,
  X,
  User,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  Bot,
  Sparkles,
  Lock
} from 'lucide-react';
import { ChatSession, CustomGPT, UserSettings } from '../types';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onTogglePinSession: (id: string) => void;
  customGpts: CustomGPT[];
  activeGptId?: string;
  onSelectGpt: (gpt: CustomGPT | null) => void;
  onOpenGptStore: () => void;
  onOpenSettings: () => void;
  isTemporaryChat: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onToggle,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onTogglePinSession,
  customGpts,
  activeGptId,
  onSelectGpt,
  onOpenGptStore,
  onOpenSettings,
  isTemporaryChat
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const handleStartRename = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(session.id);
    setEditingTitle(session.title);
  };

  const handleSaveRename = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editingTitle.trim()) {
      onRenameSession(id, editingTitle.trim());
    }
    setEditingSessionId(null);
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(null);
  };

  const filteredSessions = sessions.filter(s =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pinnedSessions = filteredSessions.filter(s => s.isPinned);
  const unpinnedSessions = filteredSessions.filter(s => !s.isPinned);

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/60 z-30 backdrop-blur-xs"
          onClick={onToggle}
        />
      )}

      {/* Sidebar Main Container */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 flex flex-col w-64 bg-[#171717] text-slate-200 border-r border-white/10 transition-all duration-300 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-0 md:border-none md:overflow-hidden'
        }`}
      >
        {/* Top Header: ChatGPT Logo & New Chat */}
        <div className="p-3 flex items-center justify-between gap-2 border-b border-white/5">
          <button
            onClick={() => {
              onSelectGpt(null);
              onNewChat();
            }}
            className="flex-1 flex items-center justify-between px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm font-medium transition group"
          >
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <span>Novo chat</span>
            </div>
            <SquarePen className="w-4 h-4 text-slate-400 group-hover:text-white transition" />
          </button>

          <button
            onClick={onToggle}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition"
            title="Recolher barra lateral"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {/* Explore GPTs Link */}
        <div className="px-3 pt-2">
          <button
            onClick={onOpenGptStore}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-white/5 transition"
          >
            <Compass className="w-4 h-4 text-emerald-400" />
            <span>Explorar GPTs</span>
          </button>
        </div>

        {/* Custom GPTs Quick List */}
        {customGpts.length > 0 && (
          <div className="px-3 pt-2">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3 py-1">
              Seus GPTs
            </div>
            <div className="space-y-0.5">
              {customGpts.slice(0, 3).map((gpt) => {
                const isSelected = activeGptId === gpt.id;
                return (
                  <button
                    key={gpt.id}
                    onClick={() => onSelectGpt(gpt)}
                    className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-xl text-xs transition text-left ${
                      isSelected
                        ? 'bg-emerald-500/20 text-emerald-300 font-medium'
                        : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                    }`}
                  >
                    <span className="text-base">{gpt.icon}</span>
                    <span className="truncate">{gpt.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Filter / Search Conversations */}
        <div className="px-3 pt-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Buscar histórico..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-white/5 border border-white/5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500/50"
            />
          </div>
        </div>

        {/* Temporary Chat Warning Banner */}
        {isTemporaryChat && (
          <div className="mx-3 mt-2 p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 shrink-0" />
            <span>Conversa temporária ativa (não fica salva no histórico).</span>
          </div>
        )}

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-3 custom-scrollbar">
          {/* Pinned Chats */}
          {pinnedSessions.length > 0 && (
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3 py-1 flex items-center gap-1">
                <Pin className="w-3 h-3" />
                <span>Fixados</span>
              </div>
              <div className="space-y-0.5">
                {pinnedSessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isActive={activeSessionId === session.id}
                    editingSessionId={editingSessionId}
                    editingTitle={editingTitle}
                    setEditingTitle={setEditingTitle}
                    onSelect={() => onSelectSession(session.id)}
                    onStartRename={(e) => handleStartRename(session, e)}
                    onSaveRename={(e) => handleSaveRename(session.id, e)}
                    onCancelRename={handleCancelRename}
                    onDelete={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    onTogglePin={(e) => {
                      e.stopPropagation();
                      onTogglePinSession(session.id);
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Recent Conversations */}
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3 py-1">
              Conversas Recentes
            </div>
            {unpinnedSessions.length === 0 && pinnedSessions.length === 0 ? (
              <div className="px-3 py-6 text-center text-xs text-slate-500 font-normal">
                {searchTerm ? 'Nenhuma conversa encontrada.' : 'Sua lista de chats aparecerá aqui.'}
              </div>
            ) : (
              <div className="space-y-0.5">
                {unpinnedSessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isActive={activeSessionId === session.id}
                    editingSessionId={editingSessionId}
                    editingTitle={editingTitle}
                    setEditingTitle={setEditingTitle}
                    onSelect={() => onSelectSession(session.id)}
                    onStartRename={(e) => handleStartRename(session, e)}
                    onSaveRename={(e) => handleSaveRename(session.id, e)}
                    onCancelRename={handleCancelRename}
                    onDelete={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    onTogglePin={(e) => {
                      e.stopPropagation();
                      onTogglePinSession(session.id);
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* User Profile & Footer Settings */}
        <div className="p-3 border-t border-white/10 bg-[#171717]">
          <button
            onClick={onOpenSettings}
            className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-white/5 transition text-left group"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 text-white font-bold flex items-center justify-center text-xs shadow-sm">
                U
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-semibold text-slate-200 truncate">Usuário ChatGPT</span>
                <span className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" /> ChatGPT Plus
                </span>
              </div>
            </div>
            <SlidersHorizontal className="w-4 h-4 text-slate-400 group-hover:text-white transition" />
          </button>
        </div>
      </aside>
    </>
  );
};

interface SessionItemProps {
  session: ChatSession;
  isActive: boolean;
  editingSessionId: string | null;
  editingTitle: string;
  setEditingTitle: (t: string) => void;
  onSelect: () => void;
  onStartRename: (e: React.MouseEvent) => void;
  onSaveRename: (e: React.MouseEvent) => void;
  onCancelRename: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
  onTogglePin: (e: React.MouseEvent) => void;
}

const SessionItem: React.FC<SessionItemProps> = ({
  session,
  isActive,
  editingSessionId,
  editingTitle,
  setEditingTitle,
  onSelect,
  onStartRename,
  onSaveRename,
  onCancelRename,
  onDelete,
  onTogglePin
}) => {
  const isEditing = editingSessionId === session.id;

  return (
    <div
      onClick={onSelect}
      className={`group relative flex items-center justify-between px-3 py-2 rounded-xl text-xs transition cursor-pointer ${
        isActive
          ? 'bg-white/10 text-white font-medium'
          : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
      }`}
    >
      <div className="flex items-center gap-2.5 min-w-0 flex-1">
        <MessageSquare className="w-3.5 h-3.5 shrink-0 text-slate-400 group-hover:text-emerald-400 transition" />

        {isEditing ? (
          <input
            type="text"
            value={editingTitle}
            onChange={(e) => setEditingTitle(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            className="flex-1 bg-black/40 border border-emerald-500/50 rounded px-1.5 py-0.5 text-xs text-white focus:outline-none"
            autoFocus
          />
        ) : (
          <span className="truncate">{session.title}</span>
        )}
      </div>

      {/* Action Buttons on Hover */}
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
        {isEditing ? (
          <>
            <button
              onClick={onSaveRename}
              className="p-1 hover:text-emerald-400 transition"
              title="Salvar"
            >
              <Check className="w-3 h-3" />
            </button>
            <button
              onClick={onCancelRename}
              className="p-1 hover:text-rose-400 transition"
              title="Cancelar"
            >
              <X className="w-3 h-3" />
            </button>
          </>
        ) : (
          <>
            <button
              onClick={onTogglePin}
              className={`p-1 hover:text-amber-400 transition ${session.isPinned ? 'text-amber-400 opacity-100' : 'text-slate-400'}`}
              title={session.isPinned ? 'Desafixar' : 'Fixar no topo'}
            >
              <Pin className="w-3 h-3" />
            </button>
            <button
              onClick={onStartRename}
              className="p-1 hover:text-white transition text-slate-400"
              title="Renomear"
            >
              <Edit2 className="w-3 h-3" />
            </button>
            <button
              onClick={onDelete}
              className="p-1 hover:text-rose-400 transition text-slate-400"
              title="Excluir"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
