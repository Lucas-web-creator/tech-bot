import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Sparkles,
  User,
  Brain,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Volume2,
  RotateCcw,
  ThumbsUp,
  ThumbsDown,
  ExternalLink,
  Layout,
  Maximize2,
  X,
  Download,
  Paperclip
} from 'lucide-react';
import { Message, CanvasDocument } from '../types';

interface ChatMessageItemProps {
  message: Message;
  onOpenCanvas: (doc: CanvasDocument) => void;
  onPlayTts: (text: string, msgId: string) => void;
  onRegenerate?: () => void;
  onFeedback?: (msgId: string, type: 'like' | 'dislike') => void;
}

export const ChatMessageItem: React.FC<ChatMessageItemProps> = ({
  message,
  onOpenCanvas,
  onPlayTts,
  onRegenerate,
  onFeedback
}) => {
  const [isReasoningOpen, setIsReasoningOpen] = useState(false);
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);
  const [copiedText, setCopiedText] = useState(false);
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null);

  const isUser = message.sender === 'user';

  const handleCopyMessageText = () => {
    navigator.clipboard.writeText(message.text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const handleCopyCodeBlock = (code: string, index: number) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeIndex(index);
    setTimeout(() => setCopiedCodeIndex(null), 2000);
  };

  return (
    <div className={`py-6 px-4 md:px-6 w-full border-b border-black/5 dark:border-white/5 transition ${
      isUser ? 'bg-transparent' : 'bg-slate-50/50 dark:bg-[#1f1f1f]/50'
    }`}>
      <div className="max-w-3xl mx-auto flex gap-4 items-start">
        {/* Avatar Icon */}
        <div className="shrink-0 pt-0.5">
          {isUser ? (
            <div className="w-8 h-8 rounded-full bg-slate-700 text-white font-bold flex items-center justify-center text-xs shadow-sm">
              U
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white font-bold flex items-center justify-center shadow-md">
              <Sparkles className="w-4 h-4 fill-white" />
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 min-w-0 space-y-3">
          {/* Header Name & Timestamp */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-sm text-slate-800 dark:text-slate-100">
              {isUser ? 'Você' : 'ChatGPT'}
            </span>
            <span className="text-[11px] text-slate-400 font-normal">{message.timestamp}</span>
            {message.modelUsed && !isUser && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10 text-slate-400 font-mono">
                {message.modelUsed}
              </span>
            )}
          </div>

          {/* User Attachments */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-1">
              {message.attachments.map((att) => (
                <div key={att.id} className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-slate-700 dark:text-slate-200">
                  {att.type === 'image' && att.content ? (
                    <img src={att.content} alt={att.name} className="w-10 h-10 object-cover rounded-lg" />
                  ) : (
                    <Paperclip className="w-4 h-4 text-slate-400" />
                  )}
                  <span className="font-medium truncate max-w-[150px]">{att.name}</span>
                </div>
              ))}
            </div>
          )}

          {/* Reasoning / Thinking Step Box (o1 Style) */}
          {message.reasoning && (
            <div className="rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 overflow-hidden my-2">
              <button
                onClick={() => setIsReasoningOpen(!isReasoningOpen)}
                className="w-full flex items-center justify-between p-3 text-xs font-medium text-amber-600 dark:text-amber-400 hover:bg-black/5 dark:hover:bg-white/5 transition text-left"
              >
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 animate-pulse" />
                  <span>
                    Raciocínio lógico detalhado ({message.reasoningTimeSeconds || 4}s)
                  </span>
                </div>
                {isReasoningOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {isReasoningOpen && (
                <div className="p-3 text-xs font-mono text-slate-600 dark:text-slate-300 border-t border-black/5 dark:border-white/5 bg-black/5 dark:bg-black/20 whitespace-pre-wrap leading-relaxed">
                  {message.reasoning}
                </div>
              )}
            </div>
          )}

          {/* Search Grounding Sources */}
          {message.sources && message.sources.length > 0 && (
            <div className="space-y-1 my-2">
              <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
                Fontes pesquisadas na Web:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {message.sources.map((src, idx) => (
                  <a
                    key={idx}
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-300 text-xs transition border border-blue-500/20"
                  >
                    <span className="truncate max-w-[180px] font-medium">{src.title}</span>
                    <ExternalLink className="w-3 h-3 shrink-0" />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* DALL-E Generated Image Output */}
          {message.imageUrl && (
            <div className="my-3 relative group inline-block">
              <img
                src={message.imageUrl}
                alt="Imagem gerada pelo ChatGPT DALL-E"
                className="rounded-2xl max-w-full md:max-w-md h-auto shadow-lg border border-black/10 dark:border-white/10 cursor-pointer hover:opacity-95 transition"
                onClick={() => setEnlargedImage(message.imageUrl!)}
              />
              <button
                onClick={() => setEnlargedImage(message.imageUrl!)}
                className="absolute top-3 right-3 p-2 rounded-xl bg-black/60 text-white opacity-0 group-hover:opacity-100 transition shadow-md"
                title="Ampliar Imagem"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Canvas Interactive Card Banner */}
          {message.canvas && (
            <div
              onClick={() => onOpenCanvas(message.canvas!)}
              className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 transition cursor-pointer flex items-center justify-between gap-3 my-2 group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500 text-white font-bold shadow-sm">
                  <Layout className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                    Documento criado no Canvas
                  </div>
                  <div className="text-sm font-bold text-slate-800 dark:text-slate-100">
                    {message.canvas.title}
                  </div>
                </div>
              </div>
              <span className="text-xs px-3 py-1.5 rounded-xl bg-emerald-500 text-white font-medium group-hover:bg-emerald-600 transition">
                Abrir no Canvas →
              </span>
            </div>
          )}

          {/* Markdown Text Response */}
          <div className="text-sm md:text-base text-slate-800 dark:text-slate-200 leading-relaxed font-normal prose dark:prose-invert max-w-none">
            <ReactMarkdown
              components={{
                code({ node, inline, className, children, ...props }: any) {
                  const match = /language-(\w+)/.exec(className || '');
                  const codeString = String(children).replace(/\n$/, '');

                  if (!inline && match) {
                    return (
                      <div className="relative my-3 rounded-2xl overflow-hidden border border-black/10 dark:border-white/10 bg-[#1e1e1e] text-slate-100 shadow-md">
                        <div className="flex items-center justify-between px-4 py-2 bg-[#252526] text-xs font-mono text-slate-400 border-b border-white/5">
                          <span>{match[1]}</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleCopyCodeBlock(codeString, 1)}
                              className="flex items-center gap-1 hover:text-white transition"
                            >
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copiar</span>
                            </button>
                          </div>
                        </div>
                        <pre className="p-4 overflow-x-auto text-xs md:text-sm font-mono leading-relaxed">
                          <code>{codeString}</code>
                        </pre>
                      </div>
                    );
                  }
                  return (
                    <code className="px-1.5 py-0.5 rounded-md bg-black/5 dark:bg-white/10 text-emerald-600 dark:text-emerald-400 font-mono text-xs font-semibold" {...props}>
                      {children}
                    </code>
                  );
                }
              }}
            >
              {message.text}
            </ReactMarkdown>
          </div>

          {/* Action Bar for Assistant Message */}
          {!isUser && (
            <div className="flex items-center gap-1 pt-2 text-slate-400">
              {/* Copy button */}
              <button
                onClick={handleCopyMessageText}
                className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 hover:text-slate-700 dark:hover:text-slate-200 transition text-xs flex items-center gap-1"
                title="Copiar resposta"
              >
                {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>

              {/* Read Aloud TTS button */}
              <button
                onClick={() => onPlayTts(message.text, message.id)}
                className={`p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 hover:text-slate-700 dark:hover:text-slate-200 transition text-xs flex items-center gap-1 ${
                  message.isAudioLoading ? 'animate-pulse text-emerald-500' : ''
                }`}
                title="Ouvir resposta em voz alta"
              >
                <Volume2 className="w-3.5 h-3.5" />
              </button>

              {/* Regenerate button */}
              {onRegenerate && (
                <button
                  onClick={onRegenerate}
                  className="p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 hover:text-slate-700 dark:hover:text-slate-200 transition text-xs"
                  title="Tentar novamente"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Feedback Like / Dislike */}
              {onFeedback && (
                <>
                  <button
                    onClick={() => onFeedback(message.id, 'like')}
                    className={`p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 transition text-xs ${
                      message.feedback === 'like' ? 'text-emerald-500' : ''
                    }`}
                    title="Gostei da resposta"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onFeedback(message.id, 'dislike')}
                    className={`p-1.5 rounded-lg hover:bg-black/5 dark:hover:bg-white/10 transition text-xs ${
                      message.feedback === 'dislike' ? 'text-rose-500' : ''
                    }`}
                    title="Não gostei"
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Image Modal Preview */}
      {enlargedImage && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4" onClick={() => setEnlargedImage(null)}>
          <div className="relative max-w-4xl max-h-[90vh] bg-[#1e1e1e] rounded-3xl p-3 border border-white/10 overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <img src={enlargedImage} alt="Imagem ampliada DALL-E" className="max-w-full max-h-[80vh] object-contain rounded-2xl" />
            <div className="flex items-center justify-between pt-3 px-2">
              <span className="text-xs text-slate-400">Criado por ChatGPT DALL·E 3</span>
              <div className="flex items-center gap-2">
                <a
                  href={enlargedImage}
                  download="chatgpt-dalle-art.png"
                  className="px-3 py-1.5 rounded-xl bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-emerald-600 transition"
                >
                  <Download className="w-3.5 h-3.5" /> Download
                </a>
                <button
                  onClick={() => setEnlargedImage(null)}
                  className="p-1.5 rounded-xl bg-white/10 text-white hover:bg-white/20 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
