import React, { useState } from 'react';
import {
  X,
  SlidersHorizontal,
  User,
  Moon,
  Sun,
  Volume2,
  Trash2,
  Check,
  Sparkles
} from 'lucide-react';
import { UserSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (newSettings: UserSettings) => void;
  onClearAllHistory: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onClearAllHistory
}) => {
  const [aboutUser, setAboutUser] = useState(settings.aboutUser || '');
  const [responseStyle, setResponseStyle] = useState(settings.responseStyle || '');
  const [theme, setTheme] = useState<'dark' | 'light' | 'system'>(settings.theme || 'dark');
  const [voice, setVoice] = useState<any>(settings.voice || 'alloy');
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      ...settings,
      aboutUser,
      responseStyle,
      theme,
      voice
    });

    setIsSavedAlert(true);
    setTimeout(() => {
      setIsSavedAlert(false);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#212121] text-slate-100 w-full max-w-2xl rounded-3xl border border-white/10 shadow-2xl flex flex-col overflow-hidden animate-fade-in">
        
        {/* Modal Header */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Personalização e Configurações</h2>
              <p className="text-xs text-slate-400">Defina preferências e como o ChatGPT deve interagir com você</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Form */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          {/* Custom Instructions Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-slate-100">Instruções Personalizadas do Usuário</h3>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                O que você gostaria que o ChatGPT soubesse sobre você?
              </label>
              <textarea
                rows={3}
                placeholder="Ex: Sou desenvolvedor web sênior especializado em TypeScript e prefiro explicações diretas e objetivas..."
                value={aboutUser}
                onChange={(e) => setAboutUser(e.target.value)}
                className="w-full p-3 text-xs rounded-2xl bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 custom-scrollbar"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Como você gostaria que o ChatGPT respondesse?
              </label>
              <textarea
                rows={3}
                placeholder="Ex: Forneça sempre código tipado, inclua formatação Markdown estruturada e evite redundâncias..."
                value={responseStyle}
                onChange={(e) => setResponseStyle(e.target.value)}
                className="w-full p-3 text-xs rounded-2xl bg-black/40 border border-white/10 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 custom-scrollbar"
              />
            </div>
          </div>

          {/* Theme & Voice Settings */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            <h3 className="text-sm font-bold text-slate-100">Aparência e Voz</h3>

            <div className="grid grid-cols-2 gap-4">
              {/* Theme Picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Tema de Cores</label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTheme('dark')}
                    className={`flex-1 p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 transition ${
                      theme === 'dark'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                        : 'bg-black/30 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5" /> Escuro
                  </button>
                  <button
                    type="button"
                    onClick={() => setTheme('light')}
                    className={`flex-1 p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 transition ${
                      theme === 'light'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                        : 'bg-black/30 border-white/10 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5" /> Claro
                  </button>
                </div>
              </div>

              {/* Voice Picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">Voz Padrão de Leitura</label>
                <select
                  value={voice}
                  onChange={(e) => setVoice(e.target.value as any)}
                  className="w-full p-2.5 text-xs rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="alloy">Alloy (Neutro & Claro)</option>
                  <option value="echo">Echo (Grave & Suave)</option>
                  <option value="fable">Fable (Expressivo & Cálido)</option>
                  <option value="onyx">Onyx (Firme & Robusto)</option>
                  <option value="nova">Nova (Energética & Jovem)</option>
                  <option value="shimmer">Shimmer (Aguda & Brilhante)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Data Controls & History */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                if (confirm('Tem certeza que deseja apagar todo o seu histórico de conversas?')) {
                  onClearAllHistory();
                  onClose();
                }
              }}
              className="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-semibold flex items-center gap-2 transition"
            >
              <Trash2 className="w-3.5 h-3.5" /> Apagar Todo o Histórico
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-slate-300 transition"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-xs font-bold text-white transition flex items-center gap-1.5 shadow-md"
              >
                {isSavedAlert ? <Check className="w-4 h-4" /> : 'Salvar Preferências'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
