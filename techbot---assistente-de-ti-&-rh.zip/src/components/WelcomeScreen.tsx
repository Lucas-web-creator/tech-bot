import React from 'react';
import {
  Sparkles,
  Code2,
  Image,
  PenTool,
  Globe,
  Calculator,
  Compass,
  ArrowRight
} from 'lucide-react';
import { CustomGPT } from '../types';

interface WelcomeScreenProps {
  onSelectPrompt: (promptText: string) => void;
  activeGpt?: CustomGPT;
  onOpenGptStore: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onSelectPrompt,
  activeGpt,
  onOpenGptStore
}) => {
  const promptSuggestions = [
    {
      title: 'Criar imagem com DALL·E 3',
      subtitle: 'Crie uma ilustração cyberpunk de uma cidade ao pôr do sol',
      icon: Image,
      prompt: 'Crie uma imagem em estilo Cyberpunk de uma metrópole futurista iluminada ao pôr do sol com carros voadores.'
    },
    {
      title: 'Escrever & Redigir',
      subtitle: 'Escreva um e-mail persuasivo de lançamento de produto',
      icon: PenTool,
      prompt: 'Escreva um e-mail corporativo moderno e altamente persuasivo para lançar um novo aplicativo de produtividade.'
    },
    {
      title: 'Programação & React',
      subtitle: 'Crie um componente React funcional em TypeScript',
      icon: Code2,
      prompt: 'Crie um componente React completo em TypeScript para um Dashboard Financeiro com gráficos e cartões de métricas.'
    },
    {
      title: 'Pesquisar na Web',
      subtitle: 'Principais notícias e avanços de tecnologia recentes',
      icon: Globe,
      prompt: 'Pesquise na web quais são os avanços mais recentes em inteligência artificial e computação quântica lançados este mês.'
    }
  ];

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 max-w-3xl mx-auto w-full text-center my-auto">
      {/* Center ChatGPT Avatar Logo */}
      <div className="mb-6 flex flex-col items-center">
        {activeGpt ? (
          <div className="flex flex-col items-center animate-fade-in">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 text-4xl flex items-center justify-center shadow-inner border border-emerald-500/20 mb-3">
              {activeGpt.icon}
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
              {activeGpt.name}
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md">
              {activeGpt.description}
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500 text-white font-bold flex items-center justify-center shadow-xl mb-4 transform hover:scale-105 transition">
              <Sparkles className="w-8 h-8 fill-white" />
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100 tracking-tight">
              O que podemos criar hoje?
            </h1>
          </div>
        )}
      </div>

      {/* Custom GPT Starter Prompts OR Standard Suggestions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full my-6 text-left">
        {activeGpt ? (
          activeGpt.starterPrompts.map((promptText, idx) => (
            <button
              key={idx}
              onClick={() => onSelectPrompt(promptText)}
              className="p-4 rounded-2xl bg-white dark:bg-[#212121] border border-black/10 dark:border-white/10 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition text-slate-700 dark:text-slate-200 text-xs md:text-sm font-medium flex items-center justify-between group shadow-xs"
            >
              <span>{promptText}</span>
              <ArrowRight className="w-4 h-4 text-emerald-500 opacity-0 group-hover:opacity-100 transition shrink-0 ml-2" />
            </button>
          ))
        ) : (
          promptSuggestions.map((item, idx) => {
            const IconComponent = item.icon;
            return (
              <button
                key={idx}
                onClick={() => onSelectPrompt(item.prompt)}
                className="p-4 rounded-2xl bg-white dark:bg-[#212121] border border-black/10 dark:border-white/10 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition text-left group shadow-xs flex flex-col justify-between h-28"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-2">
                    <IconComponent className="w-4 h-4 text-emerald-500" />
                    {item.title}
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-500 transition" />
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
                  {item.subtitle}
                </p>
              </button>
            );
          })
        )}
      </div>

      {/* Explore Custom GPTs Banner */}
      {!activeGpt && (
        <button
          onClick={onOpenGptStore}
          className="mt-2 inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 hover:bg-black/10 dark:hover:bg-white/10 text-xs font-semibold text-slate-700 dark:text-slate-200 transition"
        >
          <Compass className="w-4 h-4 text-emerald-500" />
          <span>Explorar DALL·E, Code Copilot e GPTs customizados →</span>
        </button>
      )}
    </div>
  );
};
