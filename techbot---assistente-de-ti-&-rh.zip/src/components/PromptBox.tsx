import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowUp,
  Paperclip,
  Globe,
  Brain,
  Image,
  Mic,
  MicOff,
  X,
  Sparkles,
  Square
} from 'lucide-react';
import { Attachment, ChatGPTModel } from '../types';

interface PromptBoxProps {
  onSendMessage: (text: string, attachments: Attachment[]) => void;
  isLoading: boolean;
  selectedModel: ChatGPTModel;
  enableWebSearch: boolean;
  onToggleWebSearch: () => void;
  enableReasoning: boolean;
  onToggleReasoning: () => void;
}

export const PromptBox: React.FC<PromptBoxProps> = ({
  onSendMessage,
  isLoading,
  selectedModel,
  enableWebSearch,
  onToggleWebSearch,
  enableReasoning,
  onToggleReasoning
}) => {
  const [inputText, setInputText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-resize textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [inputText]);

  // Speech Recognition (Voice Input)
  const toggleRecording = () => {
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Seu navegador não possui suporte para ditado por voz. Recomendamos usar o Chrome ou Edge.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'pt-BR';
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setInputText((prev) => prev + (prev ? ' ' : '') + transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Erro no reconhecimento de voz:', event);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.start();
      recognitionRef.current = recognition;
      setIsRecording(true);
    } catch (e) {
      console.error('Falha ao iniciar ditado de voz:', e);
      setIsRecording(false);
    }
  };

  // Handle File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();

      if (file.type.startsWith('image/')) {
        reader.readAsDataURL(file);
        reader.onload = () => {
          const newAttachment: Attachment = {
            id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: 'image',
            content: reader.result as string,
            mimeType: file.type
          };
          setAttachments((prev) => [...prev, newAttachment]);
        };
      } else {
        reader.readAsText(file);
        reader.onload = () => {
          const newAttachment: Attachment = {
            id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: 'file',
            content: (reader.result as string).slice(0, 5000)
          };
          setAttachments((prev) => [...prev, newAttachment]);
        };
      }
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && attachments.length === 0) || isLoading) return;

    onSendMessage(inputText.trim(), attachments);
    setInputText('');
    setAttachments([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-4 pt-2">
      <form onSubmit={handleSubmit} className="relative flex flex-col rounded-3xl bg-[#212121] dark:bg-[#212121] bg-white border border-black/10 dark:border-white/10 shadow-xl p-3 transition-all focus-within:border-black/20 dark:focus-within:border-white/20">
        
        {/* Attachments Preview Row */}
        {attachments.length > 0 && (
          <div className="flex items-center gap-2 px-2 pb-2 overflow-x-auto custom-scrollbar border-b border-black/5 dark:border-white/5 mb-2">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-2 px-2.5 py-1 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-slate-700 dark:text-slate-200 shrink-0 relative group"
              >
                {att.type === 'image' ? (
                  <img src={att.content} alt={att.name} className="w-6 h-6 object-cover rounded-md" />
                ) : (
                  <Paperclip className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span className="max-w-[120px] truncate">{att.name}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveAttachment(att.id)}
                  className="p-0.5 rounded-full hover:bg-black/10 dark:hover:bg-white/20 text-slate-400 hover:text-white transition"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Text Input */}
        <textarea
          ref={textareaRef}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Pergunte qualquer coisa ao ChatGPT..."
          rows={1}
          className="w-full bg-transparent border-none text-slate-800 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-0 text-sm md:text-base resize-none px-2 py-1 max-h-48 custom-scrollbar"
        />

        {/* Bottom Bar Tools & Actions */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-black/5 dark:border-white/5 mt-1">
          {/* Left Action Buttons */}
          <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar">
            {/* File Upload Button */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              className="hidden"
              multiple
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition"
              title="Anexar arquivos ou imagens"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Web Search Toggle Pill */}
            <button
              type="button"
              onClick={onToggleWebSearch}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition ${
                enableWebSearch
                  ? 'bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:bg-black/5 dark:hover:bg-white/10'
              }`}
            >
              <Globe className="w-3 h-3" />
              <span>Buscar</span>
            </button>

            {/* Reasoning Toggle Pill */}
            <button
              type="button"
              onClick={onToggleReasoning}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition ${
                enableReasoning
                  ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                  : 'text-slate-400 hover:bg-black/5 dark:hover:bg-white/10'
              }`}
            >
              <Brain className="w-3 h-3" />
              <span>Pensar</span>
            </button>

            {/* Image DALL-E Quick Prompt Insert */}
            <button
              type="button"
              onClick={() => setInputText((prev) => (prev ? prev + ' ' : '') + 'Crie uma imagem de ')}
              className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium text-slate-400 hover:bg-black/5 dark:hover:bg-white/10 transition"
            >
              <Image className="w-3 h-3 text-emerald-400" />
              <span>Imagem</span>
            </button>
          </div>

          {/* Right Action Buttons: Voice Mic + Submit */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Voice Dictation Mic Button */}
            <button
              type="button"
              onClick={toggleRecording}
              className={`p-2 rounded-full transition ${
                isRecording
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'text-slate-400 hover:bg-black/5 dark:hover:bg-white/10'
              }`}
              title={isRecording ? 'Parar ditado por voz' : 'Iniciar ditado por voz'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Send Message Button */}
            <button
              type="submit"
              disabled={(!inputText.trim() && attachments.length === 0) || isLoading}
              className={`p-2 rounded-full transition ${
                inputText.trim() || attachments.length > 0
                  ? 'bg-white text-black dark:bg-white dark:text-black hover:opacity-90 shadow-md cursor-pointer'
                  : 'bg-black/10 dark:bg-white/10 text-slate-400 dark:text-slate-600 cursor-not-allowed'
              }`}
            >
              {isLoading ? (
                <Square className="w-4 h-4 fill-current animate-spin" />
              ) : (
                <ArrowUp className="w-4 h-4 font-bold stroke-[2.5]" />
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Footer Info */}
      <p className="text-[11px] text-center text-slate-400 dark:text-slate-500 mt-2 font-normal">
        O ChatGPT pode cometer erros. Considere verificar informações importantes.
      </p>
    </div>
  );
};
