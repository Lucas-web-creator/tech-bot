import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { PromptBox } from './components/PromptBox';
import { ChatMessageItem } from './components/ChatMessageItem';
import { WelcomeScreen } from './components/WelcomeScreen';
import { CanvasViewer } from './components/CanvasViewer';
import { ExploreGptsModal } from './components/ExploreGptsModal';
import { SettingsModal } from './components/SettingsModal';
import {
  ChatSession,
  Message,
  ChatGPTModel,
  CustomGPT,
  CanvasDocument,
  Attachment,
  UserSettings
} from './types';

export default function App() {
  // Theme State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('chatgpt_theme') !== 'light';
  });

  // Sidebar Open/Close State
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);

  // Model & Capabilities Toggles
  const [selectedModel, setSelectedModel] = useState<ChatGPTModel>('gpt-4o');
  const [enableWebSearch, setEnableWebSearch] = useState<boolean>(false);
  const [enableReasoning, setEnableReasoning] = useState<boolean>(false);
  const [isTemporaryChat, setIsTemporaryChat] = useState<boolean>(false);

  // Chat Sessions Storage
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('chatgpt_sessions');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [];
  });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  // Custom GPTs Store
  const [customGpts, setCustomGpts] = useState<CustomGPT[]>([]);
  const [activeGpt, setActiveGpt] = useState<CustomGPT | null>(null);
  const [isGptStoreOpen, setIsGptStoreOpen] = useState<boolean>(false);

  // Canvas Side Panel State
  const [activeCanvas, setActiveCanvas] = useState<CanvasDocument | null>(null);
  const [isCanvasOpen, setIsCanvasOpen] = useState<boolean>(false);

  // User Settings State
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem('chatgpt_settings');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      aboutUser: '',
      responseStyle: '',
      theme: 'dark',
      voice: 'alloy',
      enableWebSearch: false,
      enableReasoning: false
    };
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Apply Dark Mode Class to Root Document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('chatgpt_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('chatgpt_theme', 'light');
    }
  }, [darkMode]);

  // Persist sessions
  useEffect(() => {
    if (!isTemporaryChat) {
      localStorage.setItem('chatgpt_sessions', JSON.stringify(sessions));
    }
  }, [sessions, isTemporaryChat]);

  // Persist settings
  useEffect(() => {
    localStorage.setItem('chatgpt_settings', JSON.stringify(settings));
  }, [settings]);

  // Fetch Custom GPTs from Backend API
  useEffect(() => {
    const fetchGpts = async () => {
      try {
        const res = await fetch('/api/gpts');
        if (res.ok) {
          const data = await res.json();
          if (data.gpts) setCustomGpts(data.gpts);
        }
      } catch (e) {
        console.error('Erro ao buscar GPTs:', e);
      }
    };
    fetchGpts();
  }, []);

  const activeSession = sessions.find((s) => s.id === activeSessionId);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [activeSession?.messages, isLoading]);

  // New Chat Handler
  const handleNewChat = () => {
    setActiveSessionId(null);
    setActiveCanvas(null);
    setIsCanvasOpen(false);
  };

  // Delete Chat Session
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (activeSessionId === id) {
      setActiveSessionId(null);
    }
  };

  // Rename Chat Session
  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle } : s))
    );
  };

  // Pin/Unpin Chat Session
  const handleTogglePinSession = (id: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isPinned: !s.isPinned } : s))
    );
  };

  // Send Message Logic
  const handleSendMessage = async (text: string, attachments: Attachment[] = []) => {
    let currentSessionId = activeSessionId;
    let currentSession = activeSession;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      attachments
    };

    // If starting a new session
    if (!currentSessionId || !currentSession) {
      const newSessionId = `session-${Date.now()}`;
      const title = text.slice(0, 32) || 'Nova conversa';

      const newSession: ChatSession = {
        id: newSessionId,
        title,
        updatedAt: new Date().toLocaleDateString('pt-BR'),
        messages: [userMsg],
        gptId: activeGpt?.id,
        model: selectedModel,
        isTemporary: isTemporaryChat
      };

      if (!isTemporaryChat) {
        setSessions((prev) => [newSession, ...prev]);
      }
      setActiveSessionId(newSessionId);
      currentSessionId = newSessionId;
      currentSession = newSession;
    } else {
      // Append user message to existing session
      const updatedMessages = [...currentSession.messages, userMsg];
      setSessions((prev) =>
        prev.map((s) => (s.id === currentSessionId ? { ...s, messages: updatedMessages } : s))
      );
    }

    setIsLoading(true);

    try {
      const historyForApi = (currentSession ? [...currentSession.messages, userMsg] : [userMsg]).map((m) => ({
        sender: m.sender,
        text: m.text,
        attachments: m.attachments
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historyForApi,
          model: selectedModel,
          enableWebSearch,
          enableReasoning,
          customInstructions: {
            aboutUser: settings.aboutUser,
            responseStyle: settings.responseStyle
          },
          gptId: activeGpt?.id,
          attachments
        })
      });

      if (!response.ok) {
        throw new Error('Falha na resposta do servidor do ChatGPT.');
      }

      const data = await response.json();

      const assistantMsg: Message = {
        id: `msg-bot-${Date.now()}`,
        sender: 'assistant',
        text: data.text || 'Não foi possível gerar a resposta.',
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed || selectedModel,
        reasoning: data.reasoning,
        reasoningTimeSeconds: data.reasoningTimeSeconds,
        canvas: data.canvas,
        imageUrl: data.imageUrl,
        sources: data.sources
      };

      // Append assistant response to session
      setSessions((prev) =>
        prev.map((s) => {
          if (s.id === currentSessionId) {
            return {
              ...s,
              messages: [...s.messages, assistantMsg]
            };
          }
          return s;
        })
      );

      // Open Canvas side panel if Canvas document generated!
      if (data.canvas) {
        setActiveCanvas(data.canvas);
        setIsCanvasOpen(true);
      }

    } catch (err: any) {
      console.error('Erro na conversa com o ChatGPT:', err);
      const errorMsg: Message = {
        id: `msg-err-${Date.now()}`,
        sender: 'assistant',
        text: `⚠️ **Aviso de Conexão**: Não foi possível receber a resposta do ChatGPT (${err?.message || 'Erro de rede'}). Verifique a conexão e tente novamente.`,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      };

      setSessions((prev) =>
        prev.map((s) => (s.id === currentSessionId ? { ...s, messages: [...s.messages, errorMsg] } : s))
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Audio Voice TTS Handler
  const handlePlayTts = async (textToSpeak: string, msgId: string) => {
    setSessions((prev) =>
      prev.map((s) => ({
        ...s,
        messages: s.messages.map((m) => (m.id === msgId ? { ...m, isAudioLoading: true } : m))
      }))
    );

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToSpeak, voice: settings.voice })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.audioBase64) {
          const audio = new Audio(`data:audio/mp3;base64,${data.audioBase64}`);
          audio.play();
          return;
        }
      }
    } catch (e) {
      console.error('Erro na síntese de voz:', e);
    } finally {
      setSessions((prev) =>
        prev.map((s) => ({
          ...s,
          messages: s.messages.map((m) => (m.id === msgId ? { ...m, isAudioLoading: false } : m))
        }))
      );
    }

    // SpeechSynthesis Fallback
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak.replace(/[*#`]/g, ''));
      utterance.lang = 'pt-BR';
      window.speechSynthesis.speak(utterance);
    }
  };

  // Feedback Handler
  const handleFeedback = (msgId: string, type: 'like' | 'dislike') => {
    setSessions((prev) =>
      prev.map((s) => ({
        ...s,
        messages: s.messages.map((m) => (m.id === msgId ? { ...m, feedback: type } : m))
      }))
    );
  };

  // Create Custom GPT
  const handleCreateGpt = async (
    name: string,
    description: string,
    instructions: string,
    category: string,
    starterPrompts: string[],
    icon: string
  ) => {
    try {
      const res = await fetch('/api/gpts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, description, instructions, category, starterPrompts, icon })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.gpt) {
          setCustomGpts((prev) => [data.gpt, ...prev]);
          setActiveGpt(data.gpt);
        }
      }
    } catch (e) {
      console.error('Erro ao criar GPT:', e);
    }
  };

  // Export Chat
  const handleExportChat = () => {
    if (!activeSession || activeSession.messages.length === 0) {
      alert('Nenhuma conversa para exportar.');
      return;
    }

    const markdownText = activeSession.messages
      .map(
        (m) =>
          `### ${m.sender === 'user' ? 'Você' : 'ChatGPT'} (${m.timestamp})\n${
            m.reasoning ? `*Raciocínio:* ${m.reasoning}\n\n` : ''
          }${m.text}\n\n`
      )
      .join('---\n\n');

    const blob = new Blob([markdownText], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chatgpt-conversa-${activeSession.id}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#ffffff] dark:bg-[#212121] text-slate-800 dark:text-slate-100 transition-colors">
      {/* Sidebar Navigation */}
      <Sidebar
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={(id) => {
          setActiveSessionId(id);
          const session = sessions.find((s) => s.id === id);
          const lastCanvasMsg = session?.messages.slice().reverse().find((m) => m.canvas);
          if (lastCanvasMsg?.canvas) {
            setActiveCanvas(lastCanvasMsg.canvas);
            setIsCanvasOpen(true);
          } else {
            setIsCanvasOpen(false);
          }
        }}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onTogglePinSession={handleTogglePinSession}
        customGpts={customGpts}
        activeGptId={activeGpt?.id}
        onSelectGpt={(gpt) => {
          setActiveGpt(gpt);
          handleNewChat();
        }}
        onOpenGptStore={() => setIsGptStoreOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isTemporaryChat={isTemporaryChat}
      />

      {/* Main ChatGPT Workspace */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        {/* Header */}
        <Header
          selectedModel={selectedModel}
          onSelectModel={(m) => setSelectedModel(m)}
          enableWebSearch={enableWebSearch}
          onToggleWebSearch={() => setEnableWebSearch(!enableWebSearch)}
          enableReasoning={enableReasoning}
          onToggleReasoning={() => setEnableReasoning(!enableReasoning)}
          isCanvasOpen={isCanvasOpen}
          onToggleCanvas={() => setIsCanvasOpen(!isCanvasOpen)}
          isTemporaryChat={isTemporaryChat}
          onToggleTemporaryChat={() => setIsTemporaryChat(!isTemporaryChat)}
          activeGpt={activeGpt || undefined}
          onOpenGptStore={() => setIsGptStoreOpen(true)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          onShareChat={handleExportChat}
        />

        {/* Chat Feed or Welcome Screen */}
        <div className="flex-1 overflow-y-auto flex flex-col justify-between">
          {!activeSession || activeSession.messages.length === 0 ? (
            <WelcomeScreen
              onSelectPrompt={(pText) => handleSendMessage(pText)}
              activeGpt={activeGpt || undefined}
              onOpenGptStore={() => setIsGptStoreOpen(true)}
            />
          ) : (
            <div className="flex-1 overflow-y-auto pb-4">
              {activeSession.messages.map((msg) => (
                <ChatMessageItem
                  key={msg.id}
                  message={msg}
                  onOpenCanvas={(doc) => {
                    setActiveCanvas(doc);
                    setIsCanvasOpen(true);
                  }}
                  onPlayTts={handlePlayTts}
                  onFeedback={handleFeedback}
                />
              ))}

              {/* Typing Indicator */}
              {isLoading && (
                <div className="py-6 px-4 md:px-8 max-w-3xl mx-auto flex gap-4 items-center">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 text-white font-bold flex items-center justify-center text-xs shadow-md animate-pulse">
                    ✳
                  </div>
                  <div className="text-xs text-emerald-500 font-medium animate-pulse flex items-center gap-2">
                    <span>ChatGPT está pensando com {selectedModel}...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}

          {/* Sticky Prompt Box */}
          <PromptBox
            onSendMessage={(t, atts) => handleSendMessage(t, atts)}
            isLoading={isLoading}
            selectedModel={selectedModel}
            enableWebSearch={enableWebSearch}
            onToggleWebSearch={() => setEnableWebSearch(!enableWebSearch)}
            enableReasoning={enableReasoning}
            onToggleReasoning={() => setEnableReasoning(!enableReasoning)}
          />
        </div>
      </div>

      {/* Side-by-Side Canvas Editor Panel */}
      {isCanvasOpen && activeCanvas && (
        <CanvasViewer
          canvas={activeCanvas}
          onClose={() => setIsCanvasOpen(false)}
          onUpdateCanvasContent={(newContent) => {
            setActiveCanvas((prev) => (prev ? { ...prev, content: newContent } : null));
          }}
          onSendCanvasPrompt={(pText) => handleSendMessage(pText)}
        />
      )}

      {/* Explore Custom GPTs Modal */}
      <ExploreGptsModal
        isOpen={isGptStoreOpen}
        onClose={() => setIsGptStoreOpen(false)}
        gpts={customGpts}
        onSelectGpt={(gpt) => {
          setActiveGpt(gpt);
          handleNewChat();
        }}
        onCreateGpt={handleCreateGpt}
      />

      {/* Custom Instructions & Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          setDarkMode(newSettings.theme === 'dark');
        }}
        onClearAllHistory={() => {
          setSessions([]);
          setActiveSessionId(null);
        }}
      />
    </div>
  );
}
